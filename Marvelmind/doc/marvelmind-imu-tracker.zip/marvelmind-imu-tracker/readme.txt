 * Compatible with Python v3+

 * Numpy, crcmod and vispy is required:
sudo pip install numpy
sudo pip install crcmod
sudo pip install vispy

 * Launch main.py
